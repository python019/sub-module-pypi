def say_hello(name=None):
    if name is None:
        print("Hello, SubUx")
    else:
        print(f"Hello, {name}")
