def say_hello(name=None):
    if name is None:
        print("Hello, world")
    else:
        print(f"Hello, {name}")
