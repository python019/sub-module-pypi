# Hello World

This is n example project demonstrating how to publish a python module to PyPi

## Installation

Run the following install:

```python
pip install subuxapp
```

## Usage

```python
from helloworld import say_hello

